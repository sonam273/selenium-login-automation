# Selenium Login Test Project
This is a basic Selenium Java project for automating login functionality.
